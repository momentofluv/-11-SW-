from rest_framework import serializers
from .models import Nutrient, UserNutrient, Exercise, UserExercise, User

class ExerciseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Exercise
        fields = ['exercisename', 'met']

class UserExerciseSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserExercise
        fields = ['user', 'exercise', 'time', 'date', 'totalcalorie', 'totaltime', 'userexercisename']

class FoodSerializer(serializers.ModelSerializer):
    class Meta:
        model = Nutrient
        fields = ['foodname']

class UserNutrientSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserNutrient
        fields = ['userfoodname', 'totalcalorie', 'totalcarbonhydrate', 'totalprotein', 'totalfat', 'userfoodgrams', 'date']

class UserListSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['nickname']

class ExerciseMarkerSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserExercise
        fields = ['date']

class FoodMarkerSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserNutrient
        fields = ['date']