from django.db import models
from user.models import User 


class Exercise(models.Model):
    exercisename = models.CharField(max_length=10, unique=True) # 운동 이름
    met = models.FloatField()                                   # 1분 당 소모 칼로리
    exerciseid = models.AutoField(primary_key=True)

    def __str__(self):
        return self.exercisename

class UserExercise(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)    
    exercise = models.ForeignKey(Exercise, on_delete=models.CASCADE)    # 사용자가 선택한 운동
    userexercisename = models.CharField(max_length=50, blank=True)
    time = models.IntegerField()    # 운동 시간(분)
    date = models.DateTimeField()       # 운동한 날짜
    totalcalorie = models.FloatField(default=0)
    totaltime = models.IntegerField(default=0)
    userexerciseid = models.AutoField(primary_key=True)

    def total_calories(self):
        calories = self.time * self.exercise.met
        return calories

    
    def total_time(self):
        return self.time
    
    def save(self, *args, **kwargs):
        longest_exercise = UserExercise.objects.filter(user=self.user).order_by('totaltime').last()

        if longest_exercise:
            if longest_exercise.userexercisename:
                exercise_names = longest_exercise.userexercisename.split(', ')
                if self.exercise.exercisename not in exercise_names:
                    exercise_names.append(self.exercise.exercisename)
                    self.userexercisename = ', '.join(exercise_names)
                else:
                    self.userexercisename = longest_exercise.userexercisename
            else:
                self.userexercisename = longest_exercise.userexercisename
        else:
            self.userexercisename = self.exercise.exercisename

        previous_exercise = UserExercise.objects.filter(user=self.user).order_by('totalcalorie').last()

        if previous_exercise:
            previous_total_calories = previous_exercise.totalcalorie
            previous_total_time = previous_exercise.totaltime
        else:
            previous_total_calories = 0
            previous_total_time = 0

        # 이번 운동 기록을 누적
        self.totalcalorie = previous_total_calories + self.total_calories()
        self.totaltime = previous_total_time + self.total_time()


        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.user.nickname} - {self.userexercisename} - {self.date}"
    
class Nutrient(models.Model):
    foodname = models.CharField(max_length=100, unique=True)
    calorie = models.FloatField()
    carbonhydrate = models.FloatField()
    protein = models.FloatField()
    fat = models.FloatField()
    foodid = models.AutoField(primary_key=True)

class UserNutrient(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    food = models.ForeignKey(Nutrient, on_delete=models.CASCADE)
    userfoodname = models.CharField(max_length=500, blank=True)
    userfoodgrams = models.FloatField(default=0)
    date = models.DateTimeField()
    totalcalorie = models.FloatField(default=0)
    totalcarbonhydrate = models.FloatField(default=0)
    totalprotein = models.FloatField(default=0)
    totalfat = models.FloatField(default=0)
    usernutrientid = models.AutoField(primary_key=True)

    def total_calories(self):
        return self.food.calorie * (self.userfoodgrams / 100)
    
    def total_carbonhydrates(self):
        return self.food.carbonhydrate * (self.userfoodgrams / 100) 
    
    def total_protein(self):
        return self.food.protein * (self.userfoodgrams / 100)
    
    def total_fat(self):
        return self.food.fat * (self.userfoodgrams / 100)
    
    def save(self, *args, **kwargs):
        previous_records = UserNutrient.objects.filter(user=self.user).exclude(pk=self.pk)

        if previous_records.exists():
            # 칼로리, 탄수화물, 단백질, 지방 값을 누적
            previous_total_calorie = sum(record.totalcalorie for record in previous_records)
            previous_total_carbonhydrate = sum(record.totalcarbonhydrate for record in previous_records)
            previous_total_protein = sum(record.totalprotein for record in previous_records)
            previous_total_fat = sum(record.totalfat for record in previous_records)
            
            # userfoodname 값 업데이트
            food_names = []
            for record in previous_records:
                if record.userfoodname:
                    food_names += record.userfoodname.split(', ')

            # 현재 음식이 중복되지 않도록 확인 후 추가
            if self.food.foodname not in food_names:
                food_names.append(self.food.foodname)
            self.userfoodname = ', '.join(set(food_names))

        else:
            # 이전 기록이 없을 경우 기본값 초기화
            previous_total_calorie = 0
            previous_total_carbonhydrate = 0
            previous_total_protein = 0
            previous_total_fat = 0
            self.userfoodname = self.food.foodname 

        self.totalcalorie = previous_total_calorie + self.total_calories()
        self.totalcarbonhydrate = previous_total_carbonhydrate + self.total_carbonhydrates()
        self.totalprotein = previous_total_protein + self.total_protein()
        self.totalfat = previous_total_fat + self.total_fat()

        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.user.nickname} - {self.userfoodname} - {self.total_calories} - {self.total_carbonhydrates} - {self.total_protein} - {self.total_fat} - {self.date}"