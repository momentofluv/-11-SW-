from django.urls import path, include
from .views import exercise_list, user_exercise_list, food_list, user_nutrient_list, save_user_exercise, save_user_food, exercise_marker, food_marker

urlpatterns = [
    path("exercise/", exercise_list),
    path("exercise/<str:username>", user_exercise_list),
    path("save/exercise", save_user_exercise),
    path("save/food", save_user_food),
    path("nutrient/food", food_list),
    path("nutrient/<str:username>", user_nutrient_list),
    path("calendar/exercise/<str:username>", exercise_marker),
    path("calendar/food/<str:username>", food_marker),
]
