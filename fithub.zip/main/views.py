from django.shortcuts import render
from django.http import HttpResponse
from .models import Exercise, UserExercise, Nutrient, UserNutrient, User
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .serializers import ExerciseSerializer, FoodSerializer, UserExerciseSerializer, UserNutrientSerializer, ExerciseMarkerSerializer, FoodMarkerSerializer
from django.views.decorators.csrf import csrf_exempt # 배포 시에 반드시 제거


@api_view(['GET'])
def helloAPI(request):
    return Response('hello world!')

@api_view(['GET'])
def exercise_list(request): # 운동명만 가져오기
    exercises = Exercise.objects.all()
    serializer = ExerciseSerializer(exercises, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def user_exercise_list(request, username):
    try:
        user = User.objects.get(username=username)  
    except User.DoesNotExist:
        return Response({"error": "User not found"}, status=404)

    exercises = UserExercise.objects.filter(user=user)
    serializer = UserExerciseSerializer(exercises, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def food_list(request):     # 음식명만 가져오기
    foods = Nutrient.objects.all()
    serializer = FoodSerializer(foods, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def user_nutrient_list(request, username):
    try:
        user = User.objects.get(username=username)  
    except User.DoesNotExist:
        return Response({"error": "User not found"}, status=404)

    nutrients = UserNutrient.objects.filter(user=user)
    serializer = UserNutrientSerializer(nutrients, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def exercise_marker(request, username):
    try:
        user = User.objects.get(username=username)
    except user.DoesNotExist:
        return Response({"error": "User not found"}, status=404)
    
    userexercise = UserExercise.objects.filter(user=user)
    serializer = ExerciseMarkerSerializer(userexercise, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def food_marker(request, username):
    try:
        user = User.objects.get(username=username)
    except user.DoesNotExist:
        return Response({"error": "User not found"}, status=404)
    
    usernutrient = UserNutrient.objects.filter(user=user)
    serializer = FoodMarkerSerializer(usernutrient, many=True)
    return Response(serializer.data)


@csrf_exempt    # 배포 시에 반드시 제거
@api_view(['POST'])
def save_user_exercise(request):
    try:
        username = request.data.get('user')
        exercisename = request.data.get('exercise')
        time = request.data.get('time')
        date = request.data.get('date')

        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            return Response({"error": f"User with nickname '{username}' not found"}, status=status.HTTP_404_NOT_FOUND)

        exercise = Exercise.objects.get(exercisename=exercisename)
        user = User.objects.get(username=username)

        # user_exercise = UserExercise.objects.create(user_id = user_id,
        user_exercise = UserExercise.objects.create(
            user=user,
            exercise = exercise,
            time = time,
            date = date)
    

        serializer = UserExerciseSerializer(user_exercise)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
 
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['POST'])
def save_user_food(request):
    try:
        username = request.data.get('user')
        foodname = request.data.get('foodname')
        grams = request.data.get('grams')
        date = request.data.get('date')

        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            return Response({"error": f"User with nickname '{username}' not found"}, status=status.HTTP_404_NOT_FOUND)

        food = Nutrient.objects.get(foodname=foodname)
        user = User.objects.get(username=username)

        print(f"User: {username}, Food: {foodname}, Grams: {grams}, Date: {date}")

        user_nutrient = UserNutrient.objects.create(
            user = user,
            food = food,
            userfoodgrams = grams,
            userfoodname = foodname,
            date = date)
    
        serializer = UserNutrientSerializer(user_nutrient)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
 
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)