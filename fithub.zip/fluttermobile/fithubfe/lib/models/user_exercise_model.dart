class UserExerciseModel {
  String userexercisename;
  int totaltime;
  double totalcalorie;
  DateTime date;

  UserExerciseModel({
    required this.userexercisename,
    required this.totaltime,
    required this.totalcalorie,
    required this.date,
  });

  UserExerciseModel.fromMap(Map<String, dynamic> map)
      : userexercisename = map['userexercisename'] ?? '오늘의 운동을 추가해 보세요!',
        totaltime = map['totaltime'] ?? 0,
        totalcalorie = map['totalcalorie'] ?? 0,
        date = DateTime.now() {
    date = map['date'] != null
        ? DateTime.parse(map['date'])
        : DateTime(1970, 1, 1);
  }
}
