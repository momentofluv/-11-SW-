class NutrientModel {
  final String foodname;

  NutrientModel({
    required this.foodname,
  });

  NutrientModel.fromMap(Map<String, dynamic> map) : foodname = map['foodname'];
}
