class ExerciseModel {
  final String exercisename;
  final double met;

  ExerciseModel({
    required this.exercisename,
    required this.met,
  });

  ExerciseModel.fromMap(Map<String, dynamic> map)
      : exercisename = map['exercisename'],
        met = map['met'];
}
