class UserNutrientModel {
  String userfoodname;
  double totalcalorie, totalcarbonhydrate, totalprotein, totalfat;
  DateTime date;

  UserNutrientModel({
    required this.userfoodname,
    required this.totalcalorie,
    required this.totalcarbonhydrate,
    required this.totalprotein,
    required this.totalfat,
    required this.date,
  });

  UserNutrientModel.fromMap(Map<String, dynamic> map)
      : userfoodname = map['userfoodname'] ?? '오늘의 식단을 추가해 보세요!',
        totalcalorie = map['totalcalorie'] ?? 0,
        totalcarbonhydrate = map['totalcarbonhydrate'] ?? 0,
        totalprotein = map['totalprotein'] ?? 0,
        totalfat = map['totalfat'] ?? 0,
        date = DateTime.now() {
    date = map['date'] != null
        ? DateTime.parse(map['date'])
        : DateTime(1970, 1, 1);
  }
}
