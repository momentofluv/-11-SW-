class MarkersModel {
  final DateTime date;

  MarkersModel({required this.date});

  MarkersModel.fromMap(Map<String, dynamic> map) : date = map['date'];
}
