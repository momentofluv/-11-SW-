import 'package:flutter/material.dart';
import 'package:fithubfe/screens/add_exercise_screen.dart';
import 'package:fithubfe/screens/add_food_screen.dart';
import 'package:fithubfe/widgets/profile.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'dart:math';
import 'package:fithubfe/models/markers_model.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime? _selectedDay;
  final DateTime _focusedDay = DateTime.now();
  String username = 'test';
  List<MarkersModel> dates = [];
  List<String> markerdates = [];
  late String selectedImage;

  @override
  void initState() {
    super.initState();
    selectedImage = getRandomImage();
  }

  String getRandomImage() {
    // 이미지 목록
    List<String> imagePaths = [
      'assets/images/profile1.png',
      'assets/images/profile2.png',
      'assets/images/profile3.png',
      'assets/images/profile4.png'
    ];

    // 랜덤으로 이미지 선택
    Random random = Random();
    int index = random.nextInt(imagePaths.length);

    return imagePaths[index];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "FitHUB",
              style: TextStyle(
                fontSize: 40,
                fontFamily: "Logo",
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
              child: Flexible(
                flex: 1,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Profile(
                      nickname: "hell",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "hiyo",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "dong",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "test",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "hihihi",
                      userPhoto: Image.asset(selectedImage),
                    ),
                  ],
                ),
              ),
            ),
            TableCalendar(
              focusedDay: DateTime.now(),
              firstDay: DateTime.utc(2024, 7, 1),
              lastDay: DateTime.utc(2024, 12, 31),
              headerStyle: HeaderStyle(
                titleCentered: true,
                titleTextFormatter: (date, locale) =>
                    DateFormat.MMMM(locale).format(date),
                formatButtonVisible: false,
                headerMargin: const EdgeInsets.symmetric(vertical: 10),
                titleTextStyle: const TextStyle(
                  fontFamily: 'Pretendard',
                  fontWeight: FontWeight.w700,
                  fontSize: 25,
                ),
              ),
              calendarStyle: const CalendarStyle(
                isTodayHighlighted: true,
                selectedDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color.fromRGBO(67, 254, 120, 0.7),
                ),
                selectedTextStyle: TextStyle(
                  color: Colors.black,
                ),
                todayDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color.fromRGBO(67, 254, 120, 0.3),
                ),
                todayTextStyle: TextStyle(
                  color: Colors.black,
                ),
              ),
              selectedDayPredicate: (day) {
                return _selectedDay != null && isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = selectedDay;
                });
              },
              onPageChanged: (focusedDay) {
                setState(() {
                  _focusedDay = focusedDay;
                });
              },
            ),
            const SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: const ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(
                      Color.fromRGBO(67, 254, 120, 0.7),
                    ),
                    foregroundColor: WidgetStatePropertyAll(Colors.white),
                    fixedSize: WidgetStatePropertyAll<Size>(
                      Size(150, 40),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                AddFoodScreen(selectedDay: _focusedDay)));
                  },
                  child: const Text("식단"),
                ),
                const SizedBox(
                  width: 20,
                ),
                ElevatedButton(
                  style: const ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(
                      Colors.white,
                    ),
                    foregroundColor: WidgetStatePropertyAll(Colors.black),
                    fixedSize: WidgetStatePropertyAll<Size>(
                      Size(150, 40),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                AddExerciseScreen(selectedDay: _focusedDay)));
                  },
                  child: const Text("운동"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
