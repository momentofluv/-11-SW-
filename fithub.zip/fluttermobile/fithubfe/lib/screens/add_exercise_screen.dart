import 'package:fithubfe/component/insert_exercise.dart';
import 'package:fithubfe/models/user_exercise_model.dart';
import 'package:fithubfe/screens/add_food_screen.dart';
import 'package:flutter/material.dart';
import 'package:fithubfe/widgets/profile.dart';
import 'package:http/http.dart' as http;
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'dart:convert';
import 'dart:math';

class AddExerciseScreen extends StatefulWidget {
  final DateTime selectedDay;
  const AddExerciseScreen({super.key, required this.selectedDay});

  @override
  State<AddExerciseScreen> createState() => _AddExerciseScreenState();
}

class _AddExerciseScreenState extends State<AddExerciseScreen> {
  DateTime? _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  var index = 0;
  String username = 'test';
  UserExerciseModel? recieveduserexercise;
  UserExerciseModel emptyuser = UserExerciseModel.fromMap(
      {'exercisename': '오늘의 운동을 기록하세요!', 'totaltime': 0, 'totalcalorie': 0});
  late String selectedImage;

  @override
  void initState() {
    super.initState();
    receiveUserExerciseData();
    selectedImage = getRandomImage();
  }

  String getRandomImage() {
    // 이미지 목록
    List<String> imagePaths = [
      'assets/images/profile_1.png',
      'assets/images/profile_2.png',
      'assets/images/profile_3.png',
      'assets/images/profile_4.png'
    ];

    // 랜덤으로 이미지 선택
    Random random = Random();
    int index = random.nextInt(imagePaths.length);

    return imagePaths[index];
  }

  Future<void> receiveUserExerciseData() async {
    final response = await http
        .get(Uri.parse('http://127.0.0.1:8000/main/exercise/$username'));

    if (response.statusCode == 200) {
      String responseBody = utf8.decode(response.bodyBytes);

      List<dynamic> data = json.decode(responseBody);

      if (data.isEmpty) {
        setState(() {
          recieveduserexercise = emptyuser;
        });
      } else {
        // 데이터를 모델로 변환
        List<UserExerciseModel> exercises =
            data.map((item) => UserExerciseModel.fromMap(item)).toList();

        UserExerciseModel maxCalorie =
            exercises.reduce((a, b) => a.totalcalorie > b.totalcalorie ? a : b);

        // 상태 업데이트
        setState(() {
          recieveduserexercise = maxCalorie;
        });
      }
    } else {
      throw Exception('Failed to load exercises');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "FitHUB",
              style: TextStyle(
                fontSize: 40,
                fontFamily: "Logo",
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
              child: Flexible(
                flex: 1,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Profile(
                      nickname: "hell",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "hiyo",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "dong",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "test",
                      userPhoto: Image.asset(selectedImage),
                    ),
                    Profile(
                      nickname: "hihihi",
                      userPhoto: Image.asset(selectedImage),
                    ),
                  ],
                ),
              ),
            ),
            TableCalendar(
              focusedDay: DateTime.now(),
              firstDay: DateTime.utc(2024, 7, 1),
              lastDay: DateTime.utc(2024, 12, 31),
              headerStyle: HeaderStyle(
                titleCentered: true,
                titleTextFormatter: (date, locale) =>
                    DateFormat.MMMM(locale).format(date),
                formatButtonVisible: false,
                headerMargin: const EdgeInsets.symmetric(vertical: 10),
                titleTextStyle: const TextStyle(
                  fontFamily: 'Pretendard',
                  fontWeight: FontWeight.w700,
                  fontSize: 25,
                ),
              ),
              calendarStyle: const CalendarStyle(
                isTodayHighlighted: false,
                selectedDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color.fromRGBO(67, 254, 120, 0.7),
                ),
                selectedTextStyle: TextStyle(
                  color: Colors.black,
                ),
                todayDecoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color.fromRGBO(67, 254, 120, 0.3),
                ),
                todayTextStyle: TextStyle(
                  color: Colors.black,
                ),
              ),
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = selectedDay;
                });
              },
              onPageChanged: (focusedDay) {
                setState(() {
                  _focusedDay = focusedDay;
                });
              },
            ),
            const SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: const ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(Colors.white),
                    foregroundColor: WidgetStatePropertyAll(Colors.black),
                    fixedSize: WidgetStatePropertyAll<Size>(
                      Size(150, 40),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                AddFoodScreen(selectedDay: _focusedDay)));
                  },
                  child: const Text("식단"),
                ),
                const SizedBox(
                  width: 20,
                ),
                const ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(
                      Color.fromRGBO(67, 254, 120, 0.7),
                    ),
                    foregroundColor: WidgetStatePropertyAll(Colors.white),
                    fixedSize: WidgetStatePropertyAll<Size>(
                      Size(150, 40),
                    ),
                  ),
                  onPressed: null,
                  child:
                      Text("운동", style: TextStyle(fontWeight: FontWeight.w900)),
                ),
              ],
            ),
            const SizedBox(
              height: 30,
            ),
            recieveduserexercise == null
                ? const Center(child: CircularProgressIndicator()) // 로딩 중 표시
                : _buildExerciseCard(recieveduserexercise!), // 데이터가 있을 경우 표시
            const SizedBox(
              height: 30,
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const InsertExercise()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromRGBO(67, 254, 120, 0.5),
                  minimumSize: const Size(60, 60),
                  shape: const CircleBorder(),
                ),
                child: const Icon(
                  Icons.add,
                  size: 30,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _buildExerciseCard(UserExerciseModel exercises) {
  return Container(
    // decoration: BoxDecoration(
    //   border: Border.all(
    //     color: const Color.fromRGBO(67, 254, 120, 0.7),
    //   ),
    // ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const TextButton(
              onPressed: null,
              child: Text(
                '오늘 한 운동',
                style: TextStyle(
                    fontFamily: 'Pretendard',
                    fontWeight: FontWeight.w600,
                    fontSize: 20,
                    backgroundColor: Color.fromRGBO(67, 254, 120, 0.5),
                    color: Colors.black),
              ),
            ),
            const SizedBox(
              width: 20,
            ),
            Text(exercises.userexercisename),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const TextButton(
              onPressed: null,
              child: Text(
                '총 운동 시간',
                style: TextStyle(
                    fontFamily: 'Pretendard',
                    fontWeight: FontWeight.w600,
                    fontSize: 20,
                    backgroundColor: Color.fromRGBO(67, 254, 120, 0.5),
                    color: Colors.black),
              ),
            ),
            const SizedBox(
              width: 20,
            ),
            Text(exercises.totaltime.toString()),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const TextButton(
              onPressed: null,
              child: Text(
                '총 소모 칼로리',
                style: TextStyle(
                    fontFamily: 'Pretendard',
                    fontWeight: FontWeight.w600,
                    fontSize: 20,
                    backgroundColor: Color.fromRGBO(67, 254, 120, 0.5),
                    color: Colors.black),
              ),
            ),
            const SizedBox(
              width: 20,
            ),
            Text(exercises.totalcalorie.toString()),
          ],
        ),
      ],
    ),
  );
}
