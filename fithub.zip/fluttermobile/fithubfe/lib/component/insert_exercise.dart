import 'package:fithubfe/models/exercise_model.dart';
import 'package:fithubfe/models/user_exercise_model.dart';
import 'package:fithubfe/screens/add_exercise_screen.dart';
import 'package:fithubfe/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class InsertExercise extends StatefulWidget {
  const InsertExercise({super.key});

  @override
  State<InsertExercise> createState() => _InsertExerciseState();
}

class _InsertExerciseState extends State<InsertExercise> {
  String username = "test";
  List<ExerciseModel> exercises = [];
  ExerciseModel? selectedExercise;
  TextEditingController insertcontroller = TextEditingController();
  List<UserExerciseModel> exercise = [
    UserExerciseModel.fromMap(
        {'exercisename': '헬스, 필라테스', 'totaltime': 120, 'totalcalorie': 375.9})
  ];

  @override
  void initState() {
    super.initState();
    fetchExercises();
  }

  Future<void> fetchExercises() async {
    final response =
        await http.get(Uri.parse('http://127.0.0.1:8000/main/exercise/'));

    if (response.statusCode == 200) {
      String responseBody = utf8.decode(response.bodyBytes);

      List<dynamic> data = json.decode(responseBody);
      setState(() {
        exercises = data.map((item) => ExerciseModel.fromMap(item)).toList();
      });
    } else {
      throw Exception('Failed to load exercises');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // DropdownButton에서 exercises 리스트를 활용
              Column(
                children: [
                  DropdownButton<ExerciseModel>(
                    isExpanded: true,
                    value: selectedExercise,
                    hint: const Text('운동을 선택하세요'),
                    items: exercises.map((ExerciseModel exercise) {
                      return DropdownMenuItem<ExerciseModel>(
                        value: exercise,
                        child: Text(exercise.exercisename),
                      );
                    }).toList(),
                    onChanged: (newValue) {
                      setState(() {
                        selectedExercise = newValue;
                      });
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: insertcontroller,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: '운동 시간 (분)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async {
                  if (selectedExercise != null) {
                    try {
                      await sendUserExerciseData(
                          username,
                          selectedExercise!.exercisename,
                          int.parse(insertcontroller.text),
                          DateTime.now());
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => AddExerciseScreen(
                                  selectedDay: DateTime.now())));
                    } catch (error) {}
                  } else {
                    print('운동을 선택해 주세요.');
                  }
                },
                child: const Text('운동 기록하기'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> sendUserExerciseData(
    String username, exercisename, int time, DateTime date) async {
  Map<String, dynamic> userExerciseData = {
    'user': username,
    'exercise': exercisename,
    'time': time,
    'date': date.toIso8601String(),
  };

  final response = await http.post(
    Uri.parse('http://127.0.0.1:8000/main/save/exercise'),
    headers: {
      'Content-Type': 'application/json',
    },
    body: json.encode(userExerciseData),
  );

  if (response.statusCode == 201) {
    // UTF-8로 디코딩한 응답 본문을 출력
    String responseBody = utf8.decode(response.bodyBytes);
  } else {
    // 에러 처리
    String responseBody = utf8.decode(response.bodyBytes);
    print('Failed to save user exercise. $responseBody');
  }
}
