import 'dart:math';

import 'package:fithubfe/models/nutrient_model.dart';
import 'package:fithubfe/screens/add_food_screen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class InsertFood extends StatefulWidget {
  const InsertFood({super.key});

  @override
  State<InsertFood> createState() => _InsertFoodState();
}

class _InsertFoodState extends State<InsertFood> {
  String username = 'test';
  List<NutrientModel> foods = [];
  TextEditingController insertcontroller = TextEditingController();
  NutrientModel? selectedfood;

  @override
  void initState() {
    super.initState();
    fetchFoods();
  }

  Future<void> fetchFoods() async {
    final response =
        await http.get(Uri.parse('http://127.0.0.1:8000/main/nutrient/food'));

    if (response.statusCode == 200) {
      String responseBody = utf8.decode(response.bodyBytes);

      List<dynamic> data = json.decode(responseBody);
      setState(() {
        foods = data.map((item) => NutrientModel.fromMap(item)).toList();
      });
    } else {
      throw Exception('Failed to load exercises');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: foods.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // DropdownButton에서 exercises 리스트를 활용
                    Column(
                      children: [
                        DropdownButton<NutrientModel>(
                          isExpanded: true,
                          value: selectedfood,
                          hint: const Text('식단을 선택하세요'),
                          items: foods.map((NutrientModel food) {
                            return DropdownMenuItem<NutrientModel>(
                              value: food,
                              child: Text(food.foodname),
                            );
                          }).toList(),
                          onChanged: (newValue) {
                            setState(() {
                              selectedfood = newValue;
                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: insertcontroller,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: '섭취한 양 (g)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () async {
                        if (selectedfood != null) {
                          try {
                            await sendUserNutrientData(
                                username,
                                selectedfood!.foodname,
                                int.parse(insertcontroller.text),
                                DateTime.now());
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => AddFoodScreen(
                                        selectedDay: DateTime.now())));
                          } catch (error) {}
                        } else {
                          print('식단을 선택해 주세요.');
                        }
                      },
                      child: const Text('식단 기록하기'),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}

Future<void> sendUserNutrientData(
    String username, foodname, int grams, DateTime date) async {
  Map<String, dynamic> userNutrientData = {
    'user': username,
    'foodname': foodname,
    'grams': grams,
    'date': date.toIso8601String(),
  };

  final response = await http.post(
    Uri.parse('http://127.0.0.1:8000/main/save/food'),
    headers: {
      'Content-Type': 'application/json',
    },
    body: json.encode(userNutrientData),
  );

  if (response.statusCode == 201) {
    // UTF-8로 디코딩한 응답 본문을 출력
    String responseBody = utf8.decode(response.bodyBytes);
  } else {
    // 에러 처리
    String responseBody = utf8.decode(response.bodyBytes);
    print('Failed to save user exercise. $responseBody');
  }
}
