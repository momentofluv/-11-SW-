import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  final String nickname;
  final Image userPhoto;

  const Profile({
    super.key,
    required this.nickname,
    required this.userPhoto,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 40,
          backgroundImage: userPhoto.image,
        ),
        const SizedBox(height: 8),
        Text(
          nickname,
          style: const TextStyle(
            fontSize: 15,
          ),
        )
      ],
    );
  }
}
